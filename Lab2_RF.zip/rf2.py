import magic
import glob 

filenames = glob.glob("Dokaz/*")
for filename in filenames:
    print(magic.from_file(filename))

