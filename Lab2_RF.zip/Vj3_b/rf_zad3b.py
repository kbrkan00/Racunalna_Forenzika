import hashlib
import glob

filenames = glob.glob("Dokaz/*")
file_hash = "c15e32d27635f248c1c8b66bb012850e5b342119"

def sha1(filename):
    hash_sha1 = hashlib.sha1()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha1.update(chunk)
    return hash_sha1.hexdigest()

for filename in filenames:
    if sha1(filename) == file_hash:
        print(filename)