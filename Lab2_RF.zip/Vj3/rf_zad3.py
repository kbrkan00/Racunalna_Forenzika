import hashlib

def md5(filename):
    hash_md5 = hashlib.md5()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

print("MD5 test.docx: " + md5("test.docx"))  
print("MD5 test.jpg: " + md5("test.jpg"))

def sha1(filename):
    hash_sha1 = hashlib.sha1()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha1.update(chunk)
    return hash_sha1.hexdigest()

print("SHA1 test.docx: " + sha1("test.docx"))  
print("SHA1 test.jpg: " + sha1("test.jpg"))