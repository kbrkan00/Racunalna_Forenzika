import hashlib
import hashlib
def md5(filename):
    hash_md5 = hashlib.md5()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

print("MD5 test.txt: " + md5("test.txt"))  
print("MD5 test1.txt: " + md5("test1.txt"))

def sha1(filename):
    hash_sha1 = hashlib.sha1()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha1.update(chunk)
    return hash_sha1.hexdigest()

print("SHA1 test.txt: " + sha1("test.txt"))  
print("SHA1 test1.txt: " + sha1("test1.txt"))

def sha256(filename):
    hash_sha256 = hashlib.sha256()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_sha256.update(chunk)
    return hash_sha256.hexdigest()

print("SHA256 test.txt: " + sha256("test.txt"))  
print("SHA256 test1.txt: " + sha256("test1.txt"))